// Hello world program
public class Hello extends ConsoleProgram
{
    public void run()
    {
        System.out.println("Hello world!");
    }
}